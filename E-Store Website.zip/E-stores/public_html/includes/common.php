<?php
$con = mysqli_connect("localhost", "root", "", "estore")or die($mysqli_error($con));
session_start();
